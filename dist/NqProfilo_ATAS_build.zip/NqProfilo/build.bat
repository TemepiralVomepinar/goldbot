@echo off
REM Chiudi ATAS prima. Doppio clic per compilare e installare.
set DEST=%APPDATA%\ATAS\Indicators
where dotnet >nul 2>nul || (echo .NET SDK non trovato. Installa .NET 10 SDK & pause & exit /b 1)
dotnet build NqProfilo.csproj -c Release -nologo -clp:ErrorsOnly %* > errori.txt 2>&1
set RC=%errorlevel%
type errori.txt
if not "%RC%"=="0" (
  echo.
  echo BUILD FALLITA. errori.txt contiene SOLO gli errori: mandamelo o incolla il contenuto.
  pause
  exit /b 1
)
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "bin\Release\NqProfilo.dll" "%DEST%\" >nul
echo.
echo OK. DLL copiata in: %DEST%\NqProfilo.dll
echo Riavvia ATAS e cerca "NQ Profilo".
echo Se la tua ATAS usa un'altra cartella indicatori, copia a mano: %CD%\bin\Release\NqProfilo.dll
pause
