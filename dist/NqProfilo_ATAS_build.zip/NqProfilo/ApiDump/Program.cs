using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

// Elenca i membri pubblici dei tipi ATAS che usa l'indicatore, scrivendoli in api.txt (nessun codice ATAS viene eseguito).
var dir = args.Length > 0 ? args[0] : @"C:\Program Files (x86)\ATAS Platform";
var paths = Directory.GetFiles(RuntimeEnvironment.GetRuntimeDirectory(), "*.dll")
    .Concat(Directory.GetFiles(dir, "*.dll")).ToList();
using var mlc = new MetadataLoadContext(new PathAssemblyResolver(paths));

string[] keywords = { "Indicator", "ChartInfo", "Candle", "PriceVolume", "RenderContext", "DrawingLayout", "RenderFont", "RenderPen",
                      "InstrumentInfo", "ChartPanel", "DataProvider", "PriceChart" };
string[] dlls = { "ATAS.Indicators.dll", "OFT.Rendering.dll", "ATAS.DataFeedsCore.dll", "OFT.Attributes.dll", "Utils.Common.dll" };
var sb = new StringBuilder();
const BindingFlags F = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;

foreach (var dll in dlls)
{
    var p = Path.Combine(dir, dll);
    if (!File.Exists(p)) { sb.AppendLine($"# MANCA {dll}"); continue; }
    Type[] types;
    try { types = mlc.LoadFromAssemblyPath(p).GetTypes(); }
    catch (ReflectionTypeLoadException e) { types = e.Types.Where(t => t != null).ToArray(); }
    foreach (var t in types.Where(t => t.IsPublic && keywords.Any(k => t.Name.Contains(k))).OrderBy(t => t.FullName))
    {
        sb.AppendLine($"== {t.FullName}  (base: {SafeBase(t)})");
        try
        {
            if (t.IsEnum) { foreach (var f in t.GetFields(F)) sb.AppendLine("   " + f.Name); continue; }
            foreach (var m in t.GetMembers(F).Where(m => m is not MethodInfo mi || !mi.IsSpecialName).OrderBy(m => m.Name))
                sb.AppendLine("   " + m.MemberType + " " + m);
        }
        catch (Exception e) { sb.AppendLine("   (errore: " + e.GetType().Name + ")"); }
    }
}
File.WriteAllText("api.txt", sb.ToString());
Console.WriteLine($"Scritto api.txt ({sb.Length / 1024} KB). Mandamelo.");

static string SafeBase(Type t) { try { return t.BaseType?.FullName ?? "-"; } catch { return "?"; } }
