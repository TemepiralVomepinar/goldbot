@echo off
REM Doppio clic: crea api.txt con le firme reali dell'API della TUA ATAS. (ATAS in altra cartella: dump.bat "D:\ATAS Platform")
dotnet run -c Release -- %*
pause
