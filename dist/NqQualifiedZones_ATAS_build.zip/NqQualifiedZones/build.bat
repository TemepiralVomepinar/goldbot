@echo off
REM 1) Chiudi ATAS (altrimenti la DLL e' bloccata)
REM 2) Doppio clic su questo file
where dotnet >nul 2>nul || (echo .NET SDK non trovato. Installa .NET 8 SDK da https://dotnet.microsoft.com/download & pause & exit /b 1)
dotnet build NqQualifiedZones.csproj -c Release %*
if errorlevel 1 (echo. & echo BUILD FALLITA - leggi gli errori sopra e vedi LEGGIMI.txt & pause & exit /b 1)
echo.
echo OK: bin\Release\NqQualifiedZones.dll
pause
