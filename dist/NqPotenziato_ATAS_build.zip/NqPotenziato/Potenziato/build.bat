@echo off
REM Chiudi ATAS prima. Doppio clic per compilare.
where dotnet >nul 2>nul || (echo .NET SDK non trovato. Installa .NET 10 SDK & pause & exit /b 1)
dotnet build NqPotenziato.csproj -c Release -nologo -clp:ErrorsOnly %* > errori.txt 2>&1
set RC=%errorlevel%
type errori.txt
if not "%RC%"=="0" (
  echo.
  echo BUILD FALLITA. Il file errori.txt contiene SOLO gli errori: mandamelo o incolla il contenuto.
  pause
  exit /b 1
)
echo.
echo OK: bin\Release\NqPotenziato.dll  (copiata in %%APPDATA%%\ATAS\Indicators se la cartella esiste)
pause
