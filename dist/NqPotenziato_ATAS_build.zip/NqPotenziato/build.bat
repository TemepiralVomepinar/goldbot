@echo off
setlocal EnableExtensions
REM Chiudi ATAS prima di copiare la DLL. Doppio clic per compilare e installare.
set "PROJ=NqPotenziato"
set "DEST=%APPDATA%\ATAS\Indicators"
where dotnet >nul 2>nul || (echo .NET SDK non trovato. Installa .NET 10 SDK da https://dotnet.microsoft.com/download & pause & exit /b 1)

REM --- 1) trova la cartella di ATAS (quella che contiene ATAS.Indicators.dll) ---
set "ATAS="
if defined ATAS_DIR call :probe "%ATAS_DIR%"
if not defined ATAS call :probe "%ProgramFiles(x86)%\ATAS Platform"
if not defined ATAS call :probe "%ProgramFiles%\ATAS Platform"
if not defined ATAS call :probe "%LOCALAPPDATA%\ATAS Platform"
if not defined ATAS call :probe "%LOCALAPPDATA%\Programs\ATAS Platform"
if not defined ATAS call :probe "%ProgramFiles%\ATAS"
if not defined ATAS call :probe "C:\ATAS Platform"
if not defined ATAS call :probe "D:\ATAS Platform"
if not defined ATAS (
  echo Cerco ATAS tra i programmi in esecuzione...
  for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'ATAS*' -and $_.Path } | Select-Object -First 1).Path"`) do call :probe "%%~dpP"
)
if not defined ATAS (
  echo Cerco ATAS.Indicators.dll sul disco, puo' richiedere un minuto...
  for %%R in ("%ProgramFiles%" "%ProgramFiles(x86)%" "%LOCALAPPDATA%" "%USERPROFILE%" "C:\" "D:\") do (
    if not defined ATAS for /f "delims=" %%F in ('dir /s /b "%%~R\ATAS.Indicators.dll" 2^>nul') do if not defined ATAS call :probe "%%~dpF"
  )
)
if not defined ATAS (
  echo.
  echo Non trovo ATAS. Apri ATAS, tasto destro sulla sua icona, "Apri percorso file", e copia il percorso della cartella
  echo che contiene ATAS.Indicators.dll.
  set /p ATAS_IN=Incolla qui il percorso e premi Invio: 
  call :probe "%ATAS_IN%"
)
if not defined ATAS (
  echo.
  echo ATAS non trovata: ATAS.Indicators.dll non esiste in quel percorso. Controlla e riprova.
  pause
  exit /b 1
)
echo Uso ATAS in: %ATAS%

REM --- 2) compila ---
dotnet build %PROJ%.csproj -c Release -nologo -clp:ErrorsOnly -p:AtasDir="%ATAS%" %* > errori.txt 2>&1
set RC=%errorlevel%
type errori.txt
if not "%RC%"=="0" (
  echo.
  echo BUILD FALLITA. errori.txt contiene SOLO gli errori: mandamelo o incolla il contenuto.
  pause
  exit /b 1
)

REM --- 3) installa ---
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "bin\Release\%PROJ%.dll" "%DEST%\" >nul
echo.
echo OK. DLL copiata in: %DEST%\%PROJ%.dll
echo Riavvia ATAS e aggiungi l'indicatore al grafico.
echo Se la tua ATAS usa un'altra cartella indicatori, copia a mano: %CD%\bin\Release\%PROJ%.dll
pause
exit /b 0

:probe
set "CAND=%~1"
if not defined CAND exit /b 0
if "%CAND:~-1%"=="\" set "CAND=%CAND:~0,-1%"
if exist "%CAND%\ATAS.Indicators.dll" set "ATAS=%CAND%"
exit /b 0
